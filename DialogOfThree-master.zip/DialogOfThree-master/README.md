# DialogOfThree
Little monkey-code about threads
